<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Live Chat with Donor</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .chat-container { max-width: 600px; margin: 30px auto; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); background-color: #fff; }
        .message-box { overflow-y: scroll; height: 300px; border: 1px solid #ddd; padding: 15px; margin-bottom: 15px; }
        .message { margin-bottom: 10px; }
        .sent { text-align: right; color: #dc3545; }
        .received { text-align: left; color: #333; }
    </style>
</head>
<body>

    <?php include_once("./pages/header.php")?>
    <div class="container chat-container">
        <h3 class="text-center">Live Chat with Donor</h3>
        
        <!-- Chat Messages Display -->
        <div class="message-box" id="message-box"></div>

        <!-- Send Message Form -->
        <form id="send-message-form">
            <input type="hidden" id="sender_id" value="1"> <!-- Replace with dynamic user ID -->
            <input type="hidden" id="receiver_id" value="<?php echo $_GET['receiver_id']; ?>"> <!-- Donor's ID -->
            <div class="input-group">
                <input type="text" id="message_text" class="form-control" placeholder="Type your message..." required>
                <button class="btn btn-danger" type="submit">Send</button>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let lastTimestamp = new Date().toISOString().slice(0, 19).replace('T', ' ');

        // Function to load messages
        function loadMessages() {
            const senderId = document.getElementById("sender_id").value;
            const receiverId = document.getElementById("receiver_id").value;

            fetch(`get_messages.php?sender_id=${senderId}&receiver_id=${receiverId}&last_timestamp=${lastTimestamp}`)
                .then(response => response.json())
                .then(messages => {
                    const messageBox = document.getElementById("message-box");
                    messages.forEach(msg => {
                        const messageElement = document.createElement("p");
                        messageElement.className = msg.sender_id == senderId ? "message sent" : "message received";
                        messageElement.innerHTML = `${msg.message_text} <br><small>${msg.timestamp}</small>`;
                        messageBox.appendChild(messageElement);
                    });

                    if (messages.length) {
                        lastTimestamp = messages[messages.length - 1].timestamp;
                    }
                    messageBox.scrollTop = messageBox.scrollHeight;
                });
        }

        // Function to send a message
        document.getElementById("send-message-form").addEventListener("submit", function(event) {
            event.preventDefault();

            const senderId = document.getElementById("sender_id").value;
            const receiverId = document.getElementById("receiver_id").value;
            const messageText = document.getElementById("message_text").value;

            fetch("send_message.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: `sender_id=${senderId}&receiver_id=${receiverId}&message_text=${messageText}`
            }).then(() => {
                document.getElementById("message_text").value = "";  // Clear the input
                loadMessages();  // Refresh messages to show the new message
            });
        });

        // Load messages every 2 seconds
        setInterval(loadMessages, 2000);
        loadMessages();  // Initial load
    </script>
</body>
</html>
