<?php
include 'db_connect.php';  // Include your database connection file

$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$phone_number = $_POST['phone_number'];
$gender = $_POST['gender'];
$blood_group = $_POST['blood_group'];
$last_donation_date = $_POST['last_donation_date'];

// Insert data into the database
$sql = "INSERT INTO donors (firstname, lastname, phone_number, gender, blood_group, last_donation_date, availability)
        VALUES ('$firstname', '$lastname', '$phone_number', '$gender', '$blood_group', '$last_donation_date', TRUE)";

if (mysqli_query($conn, $sql)) {
    echo "<div style='text-align: center; margin-top: 20px;'>
            <h3 style='color: green;'>Registration Successful!</h3>
            <p>Thank you, $firstname, for registering as a donor. You can now close this page or register another donor.</p>
            <a href='donate_form.php' style='display: inline-block; padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;'>Register Another Donor</a>
          </div>";
} else {
    echo "<div style='text-align: center; margin-top: 20px;'>
            <h3 style='color: red;'>Error: Unable to register</h3>
            <p>Please try again later.</p>
          </div>";
}

mysqli_close($conn);
?>
