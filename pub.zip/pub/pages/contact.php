<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Contact Us</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

	<link rel="stylesheet" href="contact.css">
</head>
<body>

	<?php 
	include_once("./header.php")
	
	?>
	
	<div class="contact-us">

		<div class="container">
		
			<div class="contact-left">
				<h2>Let's chat.</h2> 
				<h2>Tell me about your </h2> 
				<h2>project</h2>
				<p>Let's create something together</p>

				<div class="info-box">
					<i class="fa-regular fa-envelope"></i>

					<div class="mailbox">
					<h5>Mail me at</h5>
					<a href="#">toufikhasan72150@gmail.com</a>
					</div>
				</div>
			</div>
			<div class="contact-right">
				<form action="#">
					<h2>Send us a message <i class="fa-regular fa-paper-plane"></i></h2>
					<div class="input-box">
						<input type="text" placeholder="Full Name*">
						<input type="text" placeholder="Email address*">
						<input type="text" placeholder="Subject*">
						<label class="label">tell more about your project*</label>
						<textarea name="" id="" rows="7" cols="50"></textarea>
					</div>
					<div class="submit-box">
						<input type="submit" value="Send message">
					</div>
				</form>
			</div>
		</div>
	</div>

</body>
</html>