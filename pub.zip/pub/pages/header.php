
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">



<link rel="stylesheet" href="../style.css">

     <!-- header section start -->
     <div class="header-login">
     	<div class="container">
     		<div class="login-container">
		     	<div class="header-contact">
		     		<span class="header-icon"><i class="fa-solid fa-phone"></i>+880 1750287215</span>
		     		<span class="header-icon"><i class="fa-solid fa-location-dot"></i>24/7 Emergency Service</span>
		     		<span class="header-icon"><i class="fa-regular fa-envelope"></i></i>campuspub@pub.com</span>
		     	</div>
		     	<div class="login">
		     		<a href="">Login</a>
		     	</div>
	     	</div>
     	</div>
     </div>
	<div class="header">
		<div class="container">
			<div class="header-containers">
				<div class="logo">
					<h2><a href="http://localhost/pub/">PUB</a></h2>
				</div>
				<div class="main-menu">
					<ul>
						<li><a href="http://localhost/pub/">home</a></li>
						<li><a href="">Events & Clubs <i class="fa-solid fa-caret-down"></i></a>
						<ul>
								<li><a href="#">Programming Club</a></li>
								<li><a href="#">Sports</a></li>
							</ul>
						</li>
						<li><a href="">Resources <i class="fa-solid fa-caret-down"></i></a>
							<ul>
								<li><a href="#">Library Resources</a></li>
								<li><a href="http://localhost/pub/form-register.php">Study Groups</a></li>
								<li><a href="http://localhost/pub/bus_schedule.php">Bus Schedule</a></li>
								<li><a href="http://localhost/pub/cafeteria.php">cafeteria</a></li>
							</ul>
						</li>
						<li>
						<li><a href="http://localhost/pub/donate_form.php">Blood Resources</a>
							<ul>
								<li><a href="http://localhost/pub/donate_form.php">Blood Donate</a></li>
								<li><a href="http://localhost/pub/search_donors.php">Blood Collect</a></li>
							</ul>
						</li>
						<li><a href="http://localhost/pub/pages/contact.php">contact</a></li>		
					</ul>
				</div>

			</div>
		</div>
	</div>

	<!-- header section end -->
