<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Footer Design</title>
    <style>
        .footer {
            background-color: #16a085;
            color: #ffffff;
            padding: 40px 0;
        }
        .footer h5 {
            color: #f8f9fa;
            font-weight: 600;
        }
        .footer a {
            color: #ced4da;
            text-decoration: none;
        }
        .footer a:hover {
            color: #ffffff;
            text-decoration: underline;
        }
        .footer .social-icons a {
            font-size: 20px;
            margin: 0 10px;
            color: #ced4da;
        }
        .footer .social-icons a:hover {
            color: #ffffff;
        }
        .footer .map-container {
            border: none;
            height: 150px;
            width: 100%;
            border-radius: 8px;
        }
        .footer-bottom {
            color: white;
            padding: 10px 0;
            text-align: center;
        }
    </style>
</head>
<body>

<!-- Footer Section -->
<footer class="footer">
    <div class="container">
        <div class="row">
            <!-- Menu Section -->
            <div class="col-md-3">
                <h5>Menu</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About Us</a></li>
                    <li><a href="#">Departments</a></li>
                    <li><a href="#">Events</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>

            <!-- Quick Links Section -->
            <div class="col-md-3">
                <h5>Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Admission</a></li>
                    <li><a href="#">Library</a></li>
                    <li><a href="#">Alumni</a></li>
                    <li><a href="#">Career Center</a></li>
                    <li><a href="#">Scholarships</a></li>
                </ul>
            </div>

            <!-- Map Section -->
            <div class="col-md-3">
                <h5>Campus Map</h5>
                <iframe class="map-container" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.844917912524!2d90.39945281536314!3d23.75179809463262!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b89b1b6ab4a7%3A0x60c9c7f92391b70e!2sDhaka%2C%20Bangladesh!5e0!3m2!1sen!2sbd!4v1637692864215!5m2!1sen!2sbd" allowfullscreen="" loading="lazy"></iframe>
            </div>

            <!-- Recent Posts Section -->
            <div class="col-md-3">
                <h5>Recent Posts</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Campus Orientation 2024</a></li>
                    <li><a href="#">New Courses in Computer Science</a></li>
                    <li><a href="#">Spring Semester Schedule</a></li>
                    <li><a href="#">Career Fair Highlights</a></li>
                    <li><a href="#">Guest Lecture by Industry Expert</a></li>
                </ul>
            </div>
        </div>

        <!-- Social Media Links -->
        <div class="row text-center mt-4">
            <div class="col">
                <h5>Connect with Us</h5>
                <div class="social-icons">
                    <a href="#"><i class="bi bi-facebook"></i></a>
                    <a href="#"><i class="bi bi-twitter"></i></a>
                    <a href="#"><i class="bi bi-linkedin"></i></a>
                    <a href="#"><i class="bi bi-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Bottom -->
    <div class="footer-bottom">
        <p>&copy; 2024 Campus Connect. All rights reserved.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.10.0/font/bootstrap-icons.min.js"></script>
</body>
</html>
