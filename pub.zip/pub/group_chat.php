<?php
// Start session and include the config file
session_start();

// Check if user is logged in
if (!isset($_SESSION['users'])) {
    header("Location: login.php");
    exit();
}

// Get user data from session
$user = $_SESSION['users'];

// Include the config file for database connection
include 'config.php';

// Get the group ID from the URL
$group_id = $_GET['group_id'];

// Handle the user joining the group
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['join_group'])) {
    // Insert the user into the group_members table
    $stmt = $conn->prepare("INSERT INTO group_members (group_id, user_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $group_id, $user['id']);
    $stmt->execute();
    $stmt->close();

    // Redirect to the group page
    header("Location: group.php?group_id=$group_id");
    exit();
}

// Fetch all members of the group
$stmt = $conn->prepare("SELECT u.first_name, u.last_name, u.profile_picture 
                        FROM users u 
                        INNER JOIN group_members gm ON u.id = gm.user_id 
                        WHERE gm.group_id = ?");
$stmt->bind_param("i", $group_id);
$stmt->execute();
$members_result = $stmt->get_result();
$stmt->close();

// Handle sending group chat messages
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message'])) {
    $message = $_POST['message'];
    
    // Insert the message into the group chat
    $stmt = $conn->prepare("INSERT INTO group_chat (group_id, user_id, message) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $group_id, $user['id'], $message);
    $stmt->execute();
    $stmt->close();
}

// Fetch group chat messages
$stmt = $conn->prepare("SELECT u.first_name, u.last_name, gc.message, gc.created_at 
                        FROM group_chat gc 
                        INNER JOIN users u ON gc.user_id = u.id 
                        WHERE gc.group_id = ? ORDER BY gc.created_at DESC");
$stmt->bind_param("i", $group_id);
$stmt->execute();
$messages_result = $stmt->get_result();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group Chat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h2>Group: <?php echo htmlspecialchars($group_name); ?></h2>

    <!-- Join Group Button -->
    <?php
    // Check if the user has already joined the group
    $stmt = $conn->prepare("SELECT * FROM group_members WHERE group_id = ? AND user_id = ?");
    $stmt->bind_param("ii", $group_id, $user['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    if ($result->num_rows == 0): // If not a member, show join button
    ?>
    <form method="POST" class="mb-4">
        <button type="submit" name="join_group" class="btn btn-primary">Join this Group</button>
    </form>
    <?php endif; ?>

    <!-- Display Group Members -->
    <h3>Group Members</h3>
    <ul class="list-group">
        <?php while ($member = $members_result->fetch_assoc()): ?>
            <li class="list-group-item">
                <img src="<?php echo $member['profile_picture'] ?? '/img/default-avatar.png'; ?>" 
                     alt="Profile Picture" class="img-fluid rounded-circle" 
                     style="width: 30px; height: 30px;">
                <?php echo htmlspecialchars($member['first_name'] . " " . $member['last_name']); ?>
            </li>
        <?php endwhile; ?>
    </ul>

    <!-- Group Chat -->
    <h3>Group Chat</h3>
    <div id="chat-box" class="mb-4">
        <?php while ($message = $messages_result->fetch_assoc()): ?>
            <div class="message mb-2">
                <strong><?php echo htmlspecialchars($message['first_name'] . " " . $message['last_name']); ?></strong>
                <p><?php echo htmlspecialchars($message['message']); ?></p>
                <small><?php echo $message['created_at']; ?></small>
            </div>
        <?php endwhile; ?>
    </div>

    <!-- Chat Message Input -->
    <form action="group.php?group_id=<?php echo $group_id; ?>" method="POST">
        <div class="form-group">
            <textarea name="message" class="form-control" placeholder="Type a message..." required></textarea>
        </div>
        <button type="submit" class="btn btn-primary mt-2">Send Message</button>
    </form>
</div>

</body>
</html>
