<?php
// Start session and include the config file
session_start();
include 'config.php';

// Check if user is logged in
if (!isset($_SESSION['users'])) {
    header("Location: login.php");
    exit();
}

// Get user data from session
$user = $_SESSION['users'];

// Initialize $groups_result
$groups_result = null;

// Handle group search and filter based on category
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['category'])) {
    $category_filter = $_GET['category'];

    // Query groups based on selected category
    $stmt = $conn->prepare("SELECT * FROM groups WHERE category LIKE ?");
    $category_param = "%" . $category_filter . "%";
    $stmt->bind_param("s", $category_param);
    $stmt->execute();
    $groups_result = $stmt->get_result();
    $stmt->close();
}

// Handle group creation (if necessary)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_group'])) {
    $group_name = $_POST['group_name'];
    $group_desc = $_POST['group_desc'];
    $category = $_POST['category'];

    // Insert new group into the database
    $stmt = $conn->prepare("INSERT INTO groups (group_name, group_desc, category, creator_id) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $group_name, $group_desc, $category, $user['id']);
    $stmt->execute();
    $stmt->close();

    // Redirect to group dashboard (you may need to customize this)
    header("Location: dashboard.php?section=find-group");
    exit();
}

// Determine which section to display based on menu selection
$section = $_GET['section'] ?? 'dashboard';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Study Group Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/dashboard.css">
</head>
<body>
    <div class="d-flex" id="wrapper">
        <div class="border-end bg-light" id="sidebar-wrapper">
            <div class="sidebar-heading bg-primary text-white">Study Group</div>
            <div class="list-group list-group-flush">
                <a href="dashboard.php?section=dashboard" class="list-group-item list-group-item-action list-group-item-light p-3">Dashboard</a>
                <a href="dashboard.php?section=find-group" class="list-group-item list-group-item-action list-group-item-light p-3">Find a Group</a>
                <a href="dashboard.php?section=create-group" class="list-group-item list-group-item-action list-group-item-light p-3">Create a Group</a>
                <a href="dashboard.php?section=my-groups" class="list-group-item list-group-item-action list-group-item-light p-3">My Groups</a>
                <a href="dashboard.php?section=profile" class="list-group-item list-group-item-action list-group-item-light p-3">Profile</a>
            </div>
        </div>

        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                <div class="container-fluid">
                    <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>
                    <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>

            <div class="container-fluid">
                <!-- Dashboard Section -->
                <?php if ($section == 'dashboard'): ?>
                    <h1 class="mt-4">Dashboard</h1>
                    <p>Welcome, <?php echo htmlspecialchars($user['first_name'] . " " . $user['last_name']); ?>!</p>

                <!-- Find a Group Section -->
                <?php elseif ($section == 'find-group'): ?>
                    <h3 class="mt-4">Find a Group</h3>
                    <form method="GET" action="dashboard.php">
                        <input type="hidden" name="section" value="find-group">
                        <div class="mb-3">
                            <label for="category_filter" class="form-label">Filter by Category</label>
                            <select name="category" id="category_filter" class="form-control">
                                <option value="">All Categories</option>
                                <option value="Artificial Intelligence">Artificial Intelligence</option>
                                <option value="Machine Learning">Machine Learning</option>
                                <option value="Web Development">Web Development</option>
                                <option value="Cybersecurity">Cybersecurity</option>
                                <option value="Computer Network">Computer Network</option>
                                <option value="Hardware">Hardware</option>
                                <option value="Software Development">Software Development</option>
                                <option value="Cloud Engineering">Cloud Engineering</option>
                                <option value="Systems Analysis">Systems Analysis</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-secondary">Filter Groups</button>
                    </form>

                    <?php if ($groups_result && $groups_result->num_rows > 0): ?>
                        <ul class="list-group mt-4">
                            <?php while ($group = $groups_result->fetch_assoc()): ?>
                                <li class="list-group-item">
                                    <h5>
                                        <a href="group_dashboard.php?group_id=<?php echo $group['id']; ?>">
                                            <?php echo htmlspecialchars($group['group_name']); ?>
                                        </a>
                                    </h5>
                                    <p><?php echo htmlspecialchars($group['group_desc']); ?></p>
                                    <p><strong>Category:</strong> <?php echo htmlspecialchars($group['category']); ?></p>
                                    <form action="dashboard.php" method="POST">
                                        <input type="hidden" name="group_id" value="<?php echo $group['id']; ?>">
                                        <button type="submit" name="join_group" class="btn btn-primary">Join Group</button>
                                    </form>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    <?php else: ?>
                        <p>No groups found for this category.</p>
                    <?php endif; ?>

                <!-- Create a Group Section -->
                <?php elseif ($section == 'create-group'): ?>
                    <h3 class="mt-4">Create a New Group</h3>
                    <form method="POST" action="dashboard.php?section=create-group">
                        <div class="mb-3">
                            <label for="group_name" class="form-label">Group Name</label>
                            <input type="text" name="group_name" id="group_name" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="group_desc" class="form-label">Group Description</label>
                            <textarea name="group_desc" id="group_desc" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="category" class="form-label">Category</label>
                            <select name="category" id="category" class="form-control" required>
                                <option value="Artificial Intelligence">Artificial Intelligence</option>
                                <option value="Machine Learning">Machine Learning</option>
                                <option value="Web Development">Web Development</option>
                                <option value="Cybersecurity">Cybersecurity</option>
                                <option value="Computer Network">Computer Network</option>
                                <option value="Hardware">Hardware</option>
                                <option value="Software Development">Software Development</option>
                                <option value="Cloud Engineering">Cloud Engineering</option>
                                <option value="Systems Analysis">Systems Analysis</option>
                            </select>
                        </div>
                        <button type="submit" name="create_group" class="btn btn-primary">Create Group</button>
                    </form>

                <!-- Profile Section -->
                <?php elseif ($section == 'profile'): ?>
                    <h3 class="mt-4">Your Profile</h3>
                    <p><strong>User ID:</strong> <?php echo htmlspecialchars($user['id']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                    
                    <!-- Password Update Form -->
                    <h4>Update Password</h4>
                    <?php if (isset($password_update_message)): ?>
                        <div class="alert alert-info"><?php echo $password_update_message; ?></div>
                    <?php endif; ?>
                    <form method="POST" action="dashboard.php?section=profile">
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Current Password</label>
                            <input type="password" name="current_password" id="current_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password</label>
                            <input type="password" name="new_password" id="new_password" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password</label>
                            <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
                        </div>
                        <button type="submit" name="update_password" class="btn btn-primary">Update Password</button>
                    </form>

                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/js/dashboard.js"></script>
</body>
</html>
