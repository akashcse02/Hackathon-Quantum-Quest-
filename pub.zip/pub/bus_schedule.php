<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>University Bus Schedule</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <script>
    // Simulated function to fetch GPS data
    function fetchGPSData() {
      return [
        { busNumber: "01", location: "Main Campus" },
        { busNumber: "02", location: "Main Campus" },
        { busNumber: "03", location: "Main Campus" },
        { busNumber: "04", location: "Main Campus" },
        { busNumber: "06", location: "Main Campus" }
      ];
    }

    function updateBusLocations() {
      const gpsData = fetchGPSData();
      gpsData.forEach(bus => {
        const locationCell = document.querySelector(`td[data-bus-number="${bus.busNumber}"]`);
        if (locationCell) {
          locationCell.textContent = bus.location;
        }
      });
    }

    setInterval(updateBusLocations, 30000);

    window.onload = updateBusLocations;
  </script>
  <style>
    /* Custom styles for the table */
    .schedule-table {
      margin-top: 30px;
    }
    .schedule-table th,
    .schedule-table td {
      text-align: center;
      vertical-align: middle;
    }
    .schedule-table td {
      font-weight: 500;
    }
    .schedule-table th {
      background-color: #007bff;
      color: white;
    }
    .schedule-table tr:nth-child(even) {
      background-color: red;
    }
    .schedule-table tr:hover {
      background-color: #f1f1f1;
    }
  </style>
</head>
<body>
<?php 

include('./pages/header.php');

?>
  <div class="container">
    <h1 class="mt-5 mb-4 text-center">University Bus Schedule</h1>
    <table class="table table-bordered schedule-table">
      <thead>
        <tr>
          <th>Time</th>
          <th>Bus Number</th>
          <th>Route</th>
          <th>Current Location</th>
          <th>Notes</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>6:55AM</td>
          <td>01</td>
          <td>Main Campus to Sherpur</td>
          <td data-bus-number="01">Main Campus</td>
          <td>On Time</td>
        </tr>
        <tr>
          <td>8:05 AM</td>
          <td>02</td>
          <td>Main Campus to Sathmatha</td>
          <td data-bus-number="02">En Route</td>
          <td>Delayed</td>
        </tr>
        <tr>
          <td>7:50 AM</td>
          <td>03</td>
          <td>Main Campus to Banani</td>
          <td data-bus-number="03">South Campus</td>
          <td>On Time</td>
        </tr>
        <tr>
          <td>1:15 PM</td>
          <td>04</td>
          <td>Main Campus to Sherpur</td>
          <td data-bus-number="04">North Campus</td>
          <td>On Time</td>
        </tr>
        <tr>
          <td>8:05 PM</td>
          <td>06</td>
          <td>Main Campus to Mokamtola</td>
          <td data-bus-number="06">Cancelled</td>
          <td>Cancelled</td>
        </tr>
      </tbody>
    </table>
  </div>
  <?php include_once("./pages/footer.php")?>
</body>
</html>
