<?php
// Start session and include the config file
session_start();

// Check if user is logged in
if (!isset($_SESSION['users'])) {
    header("Location: login.php");
    exit();
}

// Get user data from session
$user = $_SESSION['users'];

// Include the config file for database connection
include 'config.php';

// Handle password change
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Verify current password
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $user['id']);
    $stmt->execute();
    $stmt->bind_result($hashed_password);
    $stmt->fetch();
    $stmt->close();
    
    if (password_verify($current_password, $hashed_password)) {
        if ($new_password === $confirm_password) {
            // Update password in the database
            $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $new_hashed_password, $user['id']);
            $stmt->execute();
            $stmt->close();
            $message = "Password updated successfully.";
        } else {
            $message = "New passwords do not match.";
        }
    } else {
        $message = "Current password is incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/profile.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">User Profile</h1>

        <!-- Profile Details Section -->
        <div class="card mb-4">
            <div class="card-body">
                <h5 class="card-title">Profile Details</h5>
                <div class="row">
                    <div class="col-md-3">
                        <img src="<?php echo $user['profile_picture'] ?? '/img/default-avatar.png'; ?>" alt="Profile Picture" class="img-fluid rounded-circle mb-3">
                    </div>
                    <div class="col-md-9">
                        <p><strong>Name:</strong> <?php echo htmlspecialchars($user['first_name'] . " " . $user['last_name']); ?></p>
                        <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                        <p><strong>Gender:</strong> <?php echo htmlspecialchars($user['gender']); ?></p>
                        
                        <!-- Profile Picture Upload Form (Optional) -->
                        <form action="profile.php" method="POST" enctype="multipart/form-data">
                            <label for="profile_picture" class="form-label">Change Profile Picture:</label>
                            <input type="file" name="profile_picture" class="form-control mb-2" required>
                            <button type="submit" name="update_profile_picture" class="btn btn-primary">Update Profile Picture</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- Password Change Section -->
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Change Password</h5>
                <?php if (isset($message)) : ?>
                    <div class="alert alert-info"><?php echo $message; ?></div>
                <?php endif; ?>
                <form action="profile.php" method="POST">
                    <div class="mb-3">
                        <label for="current_password" class="form-label">Current Password</label>
                        <input type="password" name="current_password" id="current_password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="new_password" class="form-label">New Password</label>
                        <input type="password" name="new_password" id="new_password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="confirm_password" class="form-label">Confirm New Password</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
                    </div>
                    <button type="submit" name="change_password" class="btn btn-primary">Update Password</button>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
