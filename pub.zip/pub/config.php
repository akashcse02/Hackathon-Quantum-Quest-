<?php
// Database connection settings
$host = 'localhost';  // Database host (usually localhost)
$username = 'root';   // Your MySQL username (default is 'root' for XAMPP)
$password = '';       // Your MySQL password (default is empty for XAMPP)
$dbname = 'group_study'; // The name of your database

// Create a connection to the database using MySQLi
$conn = new mysqli($host, $username, $password, $dbname);

// Check for a connection error
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
