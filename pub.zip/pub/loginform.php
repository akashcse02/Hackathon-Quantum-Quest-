

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group Study Registration</title>
    <link rel="stylesheet" href="studysignup.css">
</head>
<body>
    <div class="study-left">
        <video muted playsinline preload="auto" autoplay class="flex aspect-video w-full max-w-[340px] overflow-hidden rounded-md object-fill object-center lg:max-w-[420px] 2xl:max-w-[840px]" src="https://study-together-static-prod.st-static.com/social-login-videos/four-cameras.mp4" loop></video>
    </div>
    <div class="study-right">
        <div class="form-container">
        <h2>Login</h2>
        <form action="login.php" method="POST">
            <!-- Email -->
            <label for="email">Email Address:</label>
            <input type="email" id="email" name="email" required>

            <!-- Password -->
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <!-- Submit Button -->
            <button type="submit">Login</button>
        </form>
        </div>
    </div>
</body>
</html>



