<?php
// Start session and include the config file
session_start();

// Check if user is logged in
if (!isset($_SESSION['users'])) {
    header("Location: login.php");
    exit();
}

// Get the user data from the session
$user = $_SESSION['users']; 

// Include the config file for database connection
include 'config.php';

// Handle the group creation process
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_group'])) {
    $group_name = $_POST['group_name'];
    $group_desc = $_POST['group_desc'];
    $category = $_POST['category']; // Get the selected category

    // Insert new group into the database
    $stmt = $conn->prepare("INSERT INTO groups (group_name, group_desc, category, creator_id) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $group_name, $group_desc, $category, $user['id']);
    $stmt->execute();
    $group_id = $stmt->insert_id;
    $stmt->close();

    // Redirect to the group management page
    header("Location: dashboard.php?group_id=$group_id"); 
}

// Handle the group search (with direct selection functionality)
$search_query = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? '';
$groups_result = [];
if ($search_query || $category_filter) {
    // Prepare the search query
    $stmt = $conn->prepare("SELECT * FROM groups WHERE group_name LIKE ? AND (category LIKE ? OR ? = '')");
    $search_param = "%" . $search_query . "%";
    $category_param = "%" . $category_filter . "%";
    $stmt->bind_param("sss", $search_param, $category_param, $category_filter);
    $stmt->execute();
    $groups_result = $stmt->get_result();
    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Group Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/css/dashboard.css">
</head>
<body>
    <div class="d-flex" id="wrapper">
        <div class="border-end bg-light" id="sidebar-wrapper">
            <div class="sidebar-heading bg-primary text-white">Study Group</div>
            <div class="list-group list-group-flush">
                <a href="#dashboard" class="list-group-item list-group-item-action list-group-item-light p-3" id="dashboard-link">Dashboard</a>
                <a href="#find-group" class="list-group-item list-group-item-action list-group-item-light p-3" id="find-group-link">Find a Group</a>
                <a href="#my-groups" class="list-group-item list-group-item-action list-group-item-light p-3" id="my-groups-link">My Groups</a>
                <a href="#resources" class="list-group-item list-group-item-action list-group-item-light p-3">Resources</a>
                <a href="#community" class="list-group-item list-group-item-action list-group-item-light p-3">Community</a>
                <a href="#profile" class="list-group-item list-group-item-action list-group-item-light p-3" id="profile-link">Profile</a>
                <a href="#create-group" class="list-group-item list-group-item-action list-group-item-light p-3" id="create-group-link">Create Group</a>
            </div>
        </div>

        <div id="page-content-wrapper">
            <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
                <div class="container-fluid">
                    <button class="btn btn-primary" id="menu-toggle">Toggle Menu</button>
                    <div class="collapse navbar-collapse">
                        <ul class="navbar-nav ms-auto mt-2 mt-lg-0">
                            <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <div class="container-fluid">
                <h1 class="mt-4">Dashboard</h1>
                <p>Welcome, <?php echo htmlspecialchars($user['first_name']) . " " . htmlspecialchars($user['last_name']); ?>!</p>

                <!-- Dashboard Content -->
                <div id="dashboard-content" class="content-section">
                    <h3>Dashboard</h3>
                    <p>Here you can manage your study groups, find new groups, and more.</p>
                </div>

                <!-- Find Group Content -->
                <div id="find-group-content" class="content-section" style="display:none;">
                    <h3>Find a Group</h3>

                    <!-- Display Groups Based on Category -->
                    <?php if ($groups_result->num_rows > 0): ?>
                        <h4>Available Groups:</h4>
                        <ul class="list-group">
                            <?php while ($group = $groups_result->fetch_assoc()): ?>
                                <li class="list-group-item">
                                    <h5>
                                        <a href="<?php echo ($group['category'] === 'Machine Learning') ? 'ml_dashboard.php' : 'dashboard.php'; ?>?group_id=<?php echo $group['id']; ?>" class="text-primary">
                                            <?php echo htmlspecialchars($group['group_name']); ?>
                                        </a>
                                    </h5>
                                    <p><?php echo htmlspecialchars($group['group_desc']); ?></p>
                                    <p><strong>Category:</strong> <?php echo htmlspecialchars($group['category']); ?></p>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    <?php elseif ($search_query || $category_filter): ?>
                        <p>No groups found matching your criteria.</p>
                    <?php endif; ?>
                </div>

                <!-- Profile Content -->
                <div id="profile-content" class="content-section" style="display:none;">
                    <h3>User Profile</h3>
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title">Profile Details</h5>
                            <div class="row">
                                <div class="col-md-3">
                                    <img src="<?php echo $user['profile_picture'] ?? '/img/default-avatar.png'; ?>" alt="Profile Picture" class="img-fluid rounded-circle mb-3">
                                </div>
                                <div class="col-md-9">
                                    <p><strong>Name:</strong> <?php echo htmlspecialchars($user['first_name'] . " " . $user['last_name']); ?></p>
                                    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                                    <p><strong>Gender:</strong> <?php echo htmlspecialchars($user['gender']); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Create Group Content -->
                <div id="create-group-content" class="content-section" style="display:none;">
                    <h3>Create a New Group</h3>
                    <form action="dashboard.php" method="POST">
                        <div class="form-group">
                            <label for="group_name">Group Name</label>
                            <input type="text" name="group_name" id="group_name" class="form-control" required>
                        </div>
                        <div class="form-group mt-2">
                            <label for="group_desc">Group Description</label>
                            <textarea name="group_desc" id="group_desc" class="form-control" required></textarea>
                        </div>
                        <div class="form-group mt-2">
                            <label for="category">Category</label>
                            <select name="category" id="category" class="form-control" required>
                                <option value="Artificial Intelligence">Artificial Intelligence</option>
                                <option value="Machine Learning">Machine Learning</option>
                                <option value="Web Development">Web Development</option>
                                <option value="Cyber Security">Cyber Security</option>
                                <option value="Data Analysis">Data Analysis</option>
                                <option value="Cloud Computing">Cloud Computing</option>
                            </select>
                        </div>
                        <button type="submit" name="create_group" class="btn btn-primary mt-3">Create Group</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap and custom JavaScript -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/js/dashboard.js"></script>
</body>
</html>
