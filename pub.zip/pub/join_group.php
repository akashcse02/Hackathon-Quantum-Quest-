<?php
session_start();
include 'config.php';

if (isset($_POST['group_id']) && isset($_SESSION['users'])) {
    $user_id = $_SESSION['users']['id'];
    $group_id = $_POST['group_id'];

    // Check if user already joined the group
    $check_stmt = $conn->prepare("SELECT * FROM group_members WHERE user_id = ? AND group_id = ?");
    $check_stmt->bind_param("ii", $user_id, $group_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows == 0) {
        // Add user to the group
        $stmt = $conn->prepare("INSERT INTO group_members (user_id, group_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $user_id, $group_id);
        $stmt->execute();
        $stmt->close();
    }

    header("Location: dashboard.php?group_id=$group_id");
    exit();
}
?>
