<?php
// login.php
session_start(); // Ensure session is started

// Database connection
$conn = new mysqli('localhost', 'root', '', 'group_study');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare SQL to check user credentials
    $stmt = $conn->prepare("SELECT id, first_name, last_name, email, student_id, phone, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($user_id, $first_name, $last_name, $email, $student_id, $phone, $hashed_password);
    $stmt->fetch();

    // Check if user exists and password matches
    if ($stmt->num_rows > 0 && password_verify($password, $hashed_password)) {
        // Store user data in session
        $_SESSION['users'] = [
            'id' => $user_id,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'email' => $email,
            'student_id' => $student_id,
            'phone' => $phone
        ];

        // Redirect to dashboard.php
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Invalid email or password.";
    }

    $stmt->close();
}

$conn->close();
?>
