<?php
$servername = "localhost";
$username = "root";         // Default for XAMPP
$password = "";             // Default for XAMPP
$database = "group_study";  // Your database name

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
