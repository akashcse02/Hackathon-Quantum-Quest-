<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>University Canteen Food Menu</title>
  <link rel="stylesheet" href="./css/cafeteria.css">
 
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; }
    .container { max-width: 800px; margin: 0 auto; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
    table, th, td { border: 1px solid #ddd; }
    th, td { padding: 10px; text-align: center; }
    button { padding: 10px 20px; background-color: #4CAF50; color: white; border: none; cursor: pointer; }
    button:hover { background-color: #45a049; }
    input[type="number"], input[type="text"] { padding: 10px; width: 150px; }
    #payment-section, #otp-form { margin-top: 20px; display: none; }
  </style>
</head>
<body>

  <div class="container">
    <h1>University Canteen Menu</h1>
    <table class="food-table">
      <thead>
        <tr>
          <th>Food Item</th>
          <th>Description</th>
          <th>Price (BDT)</th>
          <th>Select Quantity</th>
        </tr>
      </thead>
      <tbody id="food-list">
        <!-- Food items will be populated here -->
      </tbody>
    </table>

    <button onclick="calculateTotal()">Calculate Total</button>
    <div id="total-price">
      <strong>Total: </strong><span id="price">0</span> BDT
    </div>

    <div id="payment-section">
      <h3>Select Payment Method</h3>
      <button onclick="initiatePayment('bKash')">Pay via bKash</button>
      <button onclick="initiatePayment('Nagad')">Pay via Nagad</button>
      <button onclick="initiatePayment('Rocket')">Pay via Rocket</button>
    </div>

    <div id="otp-form">
      <h3>Enter Your Phone Number</h3>
      <input type="text" id="phone-number" placeholder="Enter your phone number" required>
      <button onclick="sendOtp()">Send OTP</button>

      <div id="otp-input" style="display:none;">
        <input type="text" id="otp" placeholder="Enter OTP" required>
        <button onclick="verifyOtp()">Verify OTP</button>
      </div>
    </div>
  </div>

  <script>
    const foodItems = [
      { name: 'Burger', description: 'Beef or Chicken Burger', price: 30 },
      { name: 'Pizza', description: 'Cheese and Tomato Pizza', price: 50 },
      { name: 'Pasta', description: 'Spaghetti with Marinara Sauce', price: 40 },
      { name: 'Sandwich', description: 'Veggie Sandwich', price: 25 },
      { name: 'Juice', description: 'Fresh Fruit Juice', price: 15 },
      { name: 'Salad', description: 'Fresh Green Salad', price: 20 }
    ];

    function loadMenu() {
      const foodList = document.getElementById('food-list');
      foodItems.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
          <td>${item.name}</td>
          <td>${item.description}</td>
          <td>${item.price} BDT</td>
          <td><input type="number" id="${item.name}" min="0" value="0" onchange="calculateTotal()"></td>
        `;
        foodList.appendChild(row);
      });
    }

    function calculateTotal() {
      let total = 0;
      foodItems.forEach(item => {
        const quantity = document.getElementById(item.name).value;
        total += item.price * quantity;
      });
      document.getElementById('price').textContent = total.toFixed(2);

      if (total > 0) {
        document.getElementById('payment-section').style.display = 'block';
      } else {
        document.getElementById('payment-section').style.display = 'none';
      }
    }

    function initiatePayment(method) {
      const total = parseFloat(document.getElementById('price').textContent);
      if (total > 0) {
        alert(`Proceeding to payment via ${method}.`);
        document.getElementById('otp-form').style.display = 'block';
        document.getElementById('payment-section').style.display = 'none';
      } else {
        alert('Please select items before making a payment.');
      }
    }

    function sendOtp() {
      const phoneNumber = document.getElementById('phone-number').value;
      if (phoneNumber) {
        // Simulating OTP sending to the phone number
        console.log(`Sending OTP to ${phoneNumber}...`);

        // In a real-world scenario, you would send this number to your backend to trigger OTP via an API.
        document.getElementById('otp-input').style.display = 'block';
      } else {
        alert('Please enter your phone number.');
      }
    }

    function verifyOtp() {
      const otp = document.getElementById('otp').value;
      if (otp) {
        // Simulating OTP verification
        console.log(`Verifying OTP: ${otp}...`);

        // In a real-world scenario, you would send the OTP to your backend to verify with the payment provider.
        alert('Payment Successful! Your order has been confirmed.');
      } else {
        alert('Please enter the OTP.');
      }
    }

    window.onload = loadMenu;
  </script>
</body>
</html>
