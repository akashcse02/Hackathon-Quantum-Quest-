<?php
include 'db_connect.php';

$sender_id = $_POST['sender_id'];
$receiver_id = $_POST['receiver_id'];
$message_text = $_POST['message_text'];

$sql = "INSERT INTO messages (sender_id, receiver_id, message_text) VALUES ('$sender_id', '$receiver_id', '$message_text')";
mysqli_query($conn, $sql);

mysqli_close($conn);
?>
