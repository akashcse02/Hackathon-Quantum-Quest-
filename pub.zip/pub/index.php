<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Hackathon</title>

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">

	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

	<link rel="stylesheet" href="style.css">

	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

	<script src="https://cdn.jsdelivr.net/parallax.js/1.4.2/parallax.min.js"></script>


	<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

	<script type="text/javascript" src="js/scripts.js"></script>

</head>
<body>

     <?php 

     	include('./pages/header.php');

      ?>




	<!-- banner section start -->
	<div class="banner-section">
		<div class="container">
			<div class="contente">
				<h1>Hello,we are <span>Pub Family.</span> Your One-Stop Solution for <span>Campus</span> Engagement
				</h1>
				<p>Campus Connect brings students together, creating a vibrant community where you can access resources, stay informed, and engage with university life – empowering your academic and personal journey every step of the way
				</p>
			</div>

			<div class="banner-button">
				<button class="sign-up"><a href="">Sign Up For Excursion</a></button>
				<button class="learn-more"><a href="">Learn More</a></button>
			</div>
		</div>
	</div>
	<!-- banner section end -->


	<!-- about section start -->
	<div class="about-section">
		<div class="container">
			<div class="about-left">
				<h2>A Few Words About the University</h2>
				<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dicta nemo odio id dolorum ut illum corporis aut atque animi possimus officiis dolorem quibusdam eveniet repellat, blanditiis rerum ipsam? Id, eveniet.</p>

				<button class="about-learn"><a href="">Learn More </a></button>
			</div>
			<div class="about-right">
				<img src="./images/logo-about.png" alt="">
			</div>
		</div>
	</div>

	<!-- about section end -->

	<!-- Resource section start -->


	<div class="resource-section">
		<div class="resource-left">
			<img src="./images/unnamed.jpg" alt="">
		</div>
		<div class="resource-right">
			<h2>Explore Our Resources</h2>
			<p>Our Featured Courses are selected through a rigorous process and uniquely created for each semester.</p>
		</div> 
		<button class="ex-res"> <a href="">Explore All Resouces</a></button>
	</div>

	<!-- Resource section end -->


	<!-- Event section start -->
	<div class="event-section">
		<h2> Our Events</h2><hr>
		<div class="row gy-5 gx-5 mx-auto">
			<div class="col-lg-3 col-md-6 col-sm-12">
				<div class="card border-0  rounded-0 my-20 shadow">
				  <img src="images/spring-fest.png" class="card-img-top rounded-0" alt="..." d-block>
				  <div class="card-body">
				    <h5 class="card-title">Spring Fest</h5>
				  </div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-12">
				<div class="card border-0  rounded-0 shadow">
				  <img src="images/poster.png" class="card-img-top rounded-0" alt="...">
				  <div class="card-body">
				    <h5 class="card-title">Poster Presentation</h5>
				  </div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-12">
				<div class="card border-0  rounded-0 shadow">
				  <img src="images/tour.png" class="card-img-top rounded-0" alt="...">
				  <div class="card-body">
				    <h5 class="card-title">Study Tour</h5>
				  </div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-12">
				<div class="card border-0  rounded-0 shadow">
				  <img src="images/tournament.png" class="card-img-top rounded-0" alt="...">
				  <div class="card-body">
				    <h5 class="card-title">Tournament</h5>
				  </div>
				</div>
			</div>
		</div>

		<div class="event-btn">
		<button class="event-explore-btn"><a href="">Explore All Event<i class="fa-solid fa-arrow-right"></i></a></button>
		</div>
	</div>

	<?php include_once("./pages/footer.php")?>

</body>
</html>