<?php
// register.php
session_start();

// Database connection
$conn = new mysqli('localhost', 'root', '', 'group_study');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Encrypt password
    $studentID = $_POST['studentID'];
    $phone = $_POST['phone'];
    $gender = $_POST['gender'];

    // Prepare SQL
    $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, password, student_id, phone, gender) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        die("Error preparing SQL statement: " . $conn->error);
    }

    $stmt->bind_param("sssssss", $firstName, $lastName, $email, $password, $studentID, $phone, $gender);

    if ($stmt->execute()) {
        // Registration successful, show login form with success message
        echo "<h3>Registration successful! You can now log in.</h3>";
        include('loginform.php');
        exit();  // Exit so it doesn't continue executing the rest of the code
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

$conn->close();
?>


