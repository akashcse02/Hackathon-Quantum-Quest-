<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Donors</title>
    <!-- Use the same Bootstrap version for CSS and JS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
            color: #333;
        }
        .container {
            margin-top: 50px;
            max-width: 600px;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        h2 {
            color: #dc3545;
            font-weight: 700;
            text-align: center;
        }
        .btn-custom {
            background-color: #dc3545;
            color: #fff;
            border: none;
        }
        .btn-custom:hover {
            background-color: #c82333;
        }
        .donor-card {
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 10px;
        }
        .donor-card h5 {
            color: #dc3545;
        }
        .no-results {
            color: #6c757d;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Find Blood Donors</h2>
    <form action="" method="get" class="mb-4">
        <div class="form-group mb-3">
            <label for="blood_group" class="form-label">Select Blood Group:</label>
            <select name="blood_group" id="blood_group" class="form-control" required>
                <option value="A+">A+</option>
                <option value="B+">B+</option>
                <option value="AB+">AB+</option>
                <option value="A-">A-</option>
                <option value="B-">B-</option>
                <option value="AB-">AB-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
            </select>
        </div>
        <button type="submit" class="btn btn-custom w-100">Search</button>
    </form>

    <?php
    include 'db_connect.php';

    if (isset($_GET['blood_group'])) {
        $blood_group = $_GET['blood_group'];
        $sql = "SELECT * FROM donors WHERE blood_group = '$blood_group' AND availability = TRUE";
        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div class='donor-card'>";
                echo "<h5>" . htmlspecialchars($row['firstname']) . " " . htmlspecialchars($row['lastname']) . "</h5>";
                echo "<p>Phone: " . htmlspecialchars($row['phone_number']) . "<br>";
                echo "Gender: " . htmlspecialchars($row['gender']) . "<br>";
                echo "Blood Group: " . htmlspecialchars($row['blood_group']) . "<br>";
                echo "Last Donation Date: " . htmlspecialchars($row['last_donation_date']) . "<br>";
                echo "Availability: " . ($row['availability'] ? 'Available' : 'Not Available') . "</p>";
                echo "<a href='chat.php?receiver_id=" . $row['id'] . "' class='btn btn-custom'>Contact</a>";
                echo "</div>";
            }
        } else {
            echo "<p class='no-results'>No donors available for the selected blood group.</p>";
        }
    }

    mysqli_close($conn);
    ?>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
