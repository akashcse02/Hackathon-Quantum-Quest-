<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group Study Registration</title>
    <link rel="stylesheet" href="studysignup.css">
</head>
<body>

    <div class="study-left">
        <video muted playsinline preload="auto" autoplay class="flex aspect-video w-full max-w-[340px] overflow-hidden rounded-md object-fill object-center lg:max-w-[420px] 2xl:max-w-[840px]" src="https://study-together-static-prod.st-static.com/social-login-videos/four-cameras.mp4" loop></video>
    </div>
    <div class="study-right">
        <div class="form-container">
            <h2>Student Registration Form</h2>
            <form action="register.php" method="POST">
                <!-- First Name -->
                <label for="firstName">First Name:</label>
                <input type="text" id="firstName" name="firstName" required>

                <!-- Last Name -->
                <label for="lastName">Last Name:</label>
                <input type="text" id="lastName" name="lastName" required>

                <!-- Email -->
                <label for="email">Email Address:</label>
                <input type="email" id="email" name="email" required>

                <!-- Password -->
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <!-- Student ID -->
                <label for="studentID">Student ID:</label>
                <input type="text" id="studentID" name="studentID" required>

                <!-- Phone Number -->
                <label for="phone">Phone Number:</label>
                <input type="tel" id="phone" name="phone" pattern="[0-9]{10}" required placeholder="10-digit number">

                <!-- Gender -->
                <label for="gender">Gender:</label>
                <select id="gender" name="gender" required>
                    <option value="">Select Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select>

                <!-- Submit Button -->
                <button type="submit">Register</button>
            </form>
        </div>
    </div>
</body>
</html>
